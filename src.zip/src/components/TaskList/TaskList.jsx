import React, { useState, useEffect } from "react";
import AcceptTask from "./AcceptsTask";
import NewTask from "./NewTask";
import CompleteTask from "./CompleteTask";
import FailedTask from "./FailedTask";

const TaskList = ({ data }) => {
  const [tasks, setTasks] = React.useState([]);
  const [taskCounts, setTaskCounts] = React.useState({});

  React.useEffect(() => {
    // Initialize state from the provided data
    setTasks(data.tasks);
    setTaskCounts(data.taskCounts);
  }, [data]);

  const updateTaskStatus = (taskTitle, newStatus) => {
    // Update tasks
    const updatedTasks = tasks.map((task) =>
      task.taskTitle === taskTitle ? { ...task, ...newStatus } : task
    );

    // Update task counts
    const updatedTaskCounts = { ...taskCounts };
    if (newStatus.active) {
      updatedTaskCounts.active += 1;
      if (newStatus.newTask === false) updatedTaskCounts.newTask -= 1;
    } else if (newStatus.completed) {
      updatedTaskCounts.completed += 1;
      updatedTaskCounts.active -= 1;
    } else if (newStatus.failed) {
      updatedTaskCounts.failed += 1;
      updatedTaskCounts.active -= 1;
    }

    // Update local storage
    const employees = JSON.parse(localStorage.getItem("employees")) || [];
    const updatedEmployees = employees.map((employee) =>
      employee.id === data.id
        ? { ...employee, tasks: updatedTasks, taskCounts: updatedTaskCounts }
        : employee
    );

    // Persist to local storage
    localStorage.setItem("employees", JSON.stringify(updatedEmployees));

    // Update local state to reflect the changes
    setTasks(updatedTasks);
    setTaskCounts(updatedTaskCounts);
  };

  return (
    <div
      id="tasklist"
      className="h-[50%] overflow-x-auto flex items-center justify-start gap-5 flex-nowrap w-full py-1 mt-16"
    >
      {tasks.map((elem, idx) => {
        if (elem.active) {
          return (
            <AcceptTask
              key={idx}
              data={elem}
              updateTaskStatus={updateTaskStatus}
            />
          );
        }
        if (elem.newTask) {
          return (
            <NewTask
              key={idx}
              data={elem}
              updateTaskStatus={updateTaskStatus}
            />
          );
        }
        if (elem.completed) {
          return (
            <CompleteTask
              key={idx}
              data={elem}
              employeeId={data.id}
              updateTaskStatus={updateTaskStatus}
            />
          );
        }
        if (elem.failed) {
          return (
            <FailedTask
              key={idx}
              data={elem}
              updateTaskStatus={updateTaskStatus}
            />
          );
        }
        return null;
      })}
    </div>
  );
};

export default TaskList;
